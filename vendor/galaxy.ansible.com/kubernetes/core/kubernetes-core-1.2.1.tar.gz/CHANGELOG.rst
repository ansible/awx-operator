===================================
Kubernetes Collection Release Notes
===================================

.. contents:: Topics


v1.2.1
======

Bugfixes
--------

- fix missing requirements.txt file in kubernetes.core (https://github.com/ansible-collections/kubernetes.core/pull/401).
- pin molecule version to <3.3.0 to fix breaking changes (https://github.com/ansible-collections/kubernetes.core/pull/403).

v1.2.0
======

Minor Changes
-------------

- Adjust the documentation to clarify the fact ``wait_condition.status`` is a string.
- Adjust the name of parameters of ``helm`` and ``helm_info`` to match the documentation. No playbook change required.
- The Helm modules (``helm``, ``helm_info``, ``helm_plugin``, ``helm_plugin_info``, ``helm_plugin_repository``) accept the K8S environment variables like the other modules of the collections.
- helm - add a ``skip_crds`` option to skip the installation of CRDs when installing or upgrading a chart (https://github.com/ansible-collections/kubernetes.core/issues/296).
- helm - add optional support for helm diff (https://github.com/ansible-collections/kubernetes.core/issues/248).
- helm_template - add helm_template module to support template functionality (https://github.com/ansible-collections/kubernetes.core/issues/367).
- k8s - add a ``delete_options`` parameter to control garbage collection behavior when deleting a resource (https://github.com/ansible-collections/kubernetes.core/issues/253).
- k8s - add an example for downloading manifest file and applying (https://github.com/ansible-collections/kubernetes.core/issues/352).
- k8s - check if kubeconfig file is located on remote node or on Ansible Controller (https://github.com/ansible-collections/kubernetes.core/issues/307).
- k8s - check if src file is located on remote node or on Ansible Controller (https://github.com/ansible-collections/kubernetes.core/issues/307).
- k8s_exec - add a note about required permissions for the module (https://github.com/ansible-collections/kubernetes.core/issues/339).
- k8s_info - add information about api_version while returning facts (https://github.com/ansible-collections/kubernetes.core/pull/308).
- runtime.yml - update minimum Ansible version required for Kubernetes collection (https://github.com/ansible-collections/kubernetes.core/issues/314).

Bugfixes
--------

- helm - ``release_values`` makes ansible always show changed state (https://github.com/ansible-collections/kubernetes.core/issues/274)
- helm - make helm-diff plugin detection more reliable by splitting by any whitespace instead of explicit whitespace (``\s``) (https://github.com/ansible-collections/kubernetes.core/pull/362).
- helm - return values in check mode when release is not present (https://github.com/ansible-collections/kubernetes.core/issues/280).
- helm_plugin - make unused ``release_namespace`` parameter as optional (https://github.com/ansible-collections/kubernetes.core/issues/357).
- helm_plugin_info - make unused ``release_namespace`` parameter as optional (https://github.com/ansible-collections/kubernetes.core/issues/357).
- k8s - fix check_mode always showing changes when using stringData on Secrets (https://github.com/ansible-collections/kubernetes.core/issues/282).
- k8s - handle ValueError when namespace is not provided (https://github.com/ansible-collections/kubernetes.core/pull/330).
- respect the ``wait_timeout`` parameter in the ``k8s`` and ``k8s_info`` modules when a resource does not exist (https://github.com/ansible-collections/kubernetes.core/issues/344).

v1.1.1
======

Bugfixes
--------

- k8s - Fix sanity test 'compile' failing because of positional args (https://github.com/ansible-collections/kubernetes.core/issues/260).

v1.1.0
======

Major Changes
-------------

- k8s - Add support for template parameter (https://github.com/ansible-collections/kubernetes.core/pull/230).
- k8s_* - Add support for vaulted kubeconfig and src (https://github.com/ansible-collections/kubernetes.core/pull/193).

Minor Changes
-------------

- Add Makefile and downstream build script for kubernetes.core (https://github.com/ansible-collections/kubernetes.core/pull/197).
- Add execution environment metadata (https://github.com/ansible-collections/kubernetes.core/pull/211).
- Add probot stale bot configuration to autoclose issues (https://github.com/ansible-collections/kubernetes.core/pull/196).
- Added a contribution guide (https://github.com/ansible-collections/kubernetes.core/pull/192).
- Refactor module_utils (https://github.com/ansible-collections/kubernetes.core/pull/223).
- Replace KubernetesAnsibleModule class with dummy class (https://github.com/ansible-collections/kubernetes.core/pull/227).
- Replace KubernetesRawModule class with K8sAnsibleMixin (https://github.com/ansible-collections/kubernetes.core/pull/231).
- common - Do not mark task as changed when diff is irrelevant (https://github.com/ansible-collections/kubernetes.core/pull/228).
- helm - Add appVersion idempotence check to Helm (https://github.com/ansible-collections/kubernetes.core/pull/246).
- helm - Return status in check mode (https://github.com/ansible-collections/kubernetes.core/pull/192).
- helm - Support for single or multiple values files (https://github.com/ansible-collections/kubernetes.core/pull/93).
- helm_* - Support vaulted kubeconfig (https://github.com/ansible-collections/kubernetes.core/pull/229).
- k8s - SelfSubjectAccessReviews supported when 405 response received (https://github.com/ansible-collections/kubernetes.core/pull/237).
- k8s - add testcase for adding multiple resources using template parameter (https://github.com/ansible-collections/kubernetes.core/issues/243).
- k8s_info - Add support for wait (https://github.com/ansible-collections/kubernetes.core/pull/235).
- k8s_info - update custom resource example (https://github.com/ansible-collections/kubernetes.core/issues/202).
- kubectl plugin - correct console log (https://github.com/ansible-collections/kubernetes.core/issues/200).
- raw - Handle exception raised by underlying APIs (https://github.com/ansible-collections/kubernetes.core/pull/180).

Bugfixes
--------

- common - handle exception raised due to DynamicClient (https://github.com/ansible-collections/kubernetes.core/pull/224).
- helm - add replace parameter (https://github.com/ansible-collections/kubernetes.core/issues/106).
- k8s (inventory) - Set the connection plugin and transport separately (https://github.com/ansible-collections/kubernetes.core/pull/208).
- k8s (inventory) - Specify FQCN for k8s inventory plugin to fix use with Ansible 2.9 (https://github.com/ansible-collections/kubernetes.core/pull/250).
- k8s_info - add wait functionality (https://github.com/ansible-collections/kubernetes.core/issues/18).

v1.0.0
======

Major Changes
-------------

- helm_plugin - new module to manage Helm plugins (https://github.com/ansible-collections/kubernetes.core/pull/154).
- helm_plugin_info - new modules to gather information about Helm plugins (https://github.com/ansible-collections/kubernetes.core/pull/154).
- k8s_exec - Return rc for the command executed (https://github.com/ansible-collections/kubernetes.core/pull/158).

Minor Changes
-------------

- Ensure check mode results are as expected (https://github.com/ansible-collections/kubernetes.core/pull/155).
- Update base branch to 'main' (https://github.com/ansible-collections/kubernetes.core/issues/148).
- helm - Add support for K8S_AUTH_CONTEXT, K8S_AUTH_KUBECONFIG env (https://github.com/ansible-collections/kubernetes.core/pull/141).
- helm - Allow creating namespaces with Helm (https://github.com/ansible-collections/kubernetes.core/pull/157).
- helm - add aliases context for kube_context (https://github.com/ansible-collections/kubernetes.core/pull/152).
- helm - add support for K8S_AUTH_KUBECONFIG and K8S_AUTH_CONTEXT environment variable (https://github.com/ansible-collections/kubernetes.core/issues/140).
- helm_info - add aliases context for kube_context (https://github.com/ansible-collections/kubernetes.core/pull/152).
- helm_info - add support for K8S_AUTH_KUBECONFIG and K8S_AUTH_CONTEXT environment variable (https://github.com/ansible-collections/kubernetes.core/issues/140).
- k8s_exec - return RC for the command executed (https://github.com/ansible-collections/kubernetes.core/issues/122).
- k8s_info - Update example using vars (https://github.com/ansible-collections/kubernetes.core/pull/156).

Security Fixes
--------------

- kubectl - connection plugin now redact kubectl_token and kubectl_password in console log (https://github.com/ansible-collections/kubernetes.core/issues/65).
- kubectl - redacted token and password from console log (https://github.com/ansible-collections/kubernetes.core/pull/159).

Bugfixes
--------

- Test against stable ansible branch so molecule tests work (https://github.com/ansible-collections/kubernetes.core/pull/168).
- Update openshift requirements in k8s module doc (https://github.com/ansible-collections/kubernetes.core/pull/153).

New Modules
-----------

- helm_plugin - Manage Helm plugins
- helm_plugin_info - Gather information about Helm plugins

v0.11.1
=======

Major Changes
-------------

- Add changelog and fragments and document changelog process (https://github.com/ansible-collections/kubernetes.core/pull/131).

Minor Changes
-------------

- Add action groups for playbooks with module_defaults (https://github.com/ansible-collections/kubernetes.core/pull/107).
- Add requires_ansible version constraints to runtime.yml (https://github.com/ansible-collections/kubernetes.core/pull/126).
- Add sanity test ignore file for Ansible 2.11 (https://github.com/ansible-collections/kubernetes.core/pull/130).
- Add test for openshift apply bug (https://github.com/ansible-collections/kubernetes.core/pull/94).
- Add version_added to each new collection module (https://github.com/ansible-collections/kubernetes.core/pull/98).
- Check Python code using flake8 (https://github.com/ansible-collections/kubernetes.core/pull/123).
- Don't require project coverage check on PRs (https://github.com/ansible-collections/kubernetes.core/pull/102).
- Improve k8s Deployment and Daemonset wait conditions (https://github.com/ansible-collections/kubernetes.core/pull/35).
- Minor documentation fixes and use of FQCN in some examples (https://github.com/ansible-collections/kubernetes.core/pull/114).
- Remove action_groups_redirection entry from meta/runtime.yml (https://github.com/ansible-collections/kubernetes.core/pull/127).
- Remove deprecated ANSIBLE_METADATA field (https://github.com/ansible-collections/kubernetes.core/pull/95).
- Use FQCN in module docs and plugin examples (https://github.com/ansible-collections/kubernetes.core/pull/146).
- Use improved kubernetes diffs where possible (https://github.com/ansible-collections/kubernetes.core/pull/105).
- helm - add 'atomic' option (https://github.com/ansible-collections/kubernetes.core/pull/115).
- helm - minor code refactoring (https://github.com/ansible-collections/kubernetes.core/pull/110).
- helm_info and helm_repository - minor code refactor (https://github.com/ansible-collections/kubernetes.core/pull/117).
- k8s - Handle set object retrieved from lookup plugin (https://github.com/ansible-collections/kubernetes.core/pull/118).

Bugfixes
--------

- Fix suboption docs structure for inventory plugins (https://github.com/ansible-collections/kubernetes.core/pull/103).
- Handle invalid kubeconfig parsing error (https://github.com/ansible-collections/kubernetes.core/pull/119).
- Make sure Service changes run correctly in check_mode (https://github.com/ansible-collections/kubernetes.core/pull/84).
- k8s_info - remove unneccessary k8s_facts deprecation notice (https://github.com/ansible-collections/kubernetes.core/pull/97).
- k8s_scale - Fix scale wait and add tests (https://github.com/ansible-collections/kubernetes.core/pull/100).
- raw - handle condition when definition is none (https://github.com/ansible-collections/kubernetes.core/pull/139).

v0.11.0
=======

Major Changes
-------------

- helm - New module for managing Helm charts (https://github.com/ansible-collections/kubernetes.core/pull/61).
- helm_info - New module for retrieving Helm chart information (https://github.com/ansible-collections/kubernetes.core/pull/61).
- helm_repository - New module for managing Helm repositories (https://github.com/ansible-collections/kubernetes.core/pull/61).

Minor Changes
-------------

- Rename repository to ``kubernetes.core`` (https://github.com/ansible-collections/kubernetes.core/pull/81).

Bugfixes
--------

- Make sure extra files are not included in built collection (https://github.com/ansible-collections/kubernetes.core/pull/85).
- Update GitHub Actions workflow for better CI stability (https://github.com/ansible-collections/kubernetes.core/pull/78).
- k8s_log - Module no longer attempts to parse log as JSON (https://github.com/ansible-collections/kubernetes.core/pull/69).

New Modules
-----------

- helm - Manages Kubernetes packages with the Helm package manager
- helm_info - Get information from Helm package deployed inside the cluster
- helm_repository - Add and remove Helm repository

v0.10.0
=======

Major Changes
-------------

- k8s_exec - New module for executing commands on pods via Kubernetes API (https://github.com/ansible-collections/kubernetes.core/pull/14).
- k8s_log - New module for retrieving pod logs (https://github.com/ansible-collections/kubernetes.core/pull/16).

Minor Changes
-------------

- k8s - Added ``persist_config`` option for persisting refreshed tokens (https://github.com/ansible-collections/kubernetes.core/issues/49).

Security Fixes
--------------

- kubectl - Warn about information disclosure when using options like ``kubectl_password``, ``kubectl_extra_args``, and ``kubectl_token`` to pass data through to the command line using the ``kubectl`` connection plugin (https://github.com/ansible-collections/kubernetes.core/pull/51).

Bugfixes
--------

- k8s - Add exception handling when retrieving k8s client (https://github.com/ansible-collections/kubernetes.core/pull/54).
- k8s - Fix argspec for 'elements' (https://github.com/ansible-collections/kubernetes.core/issues/13).
- k8s - Use ``from_yaml`` filter with lookup examples in ``k8s`` module documentation examples (https://github.com/ansible-collections/kubernetes.core/pull/56).
- k8s_service - Fix argspec (https://github.com/ansible-collections/kubernetes.core/issues/33).
- kubectl - Fix documentation in kubectl connection plugin (https://github.com/ansible-collections/kubernetes.core/pull/52).

New Modules
-----------

- k8s_exec - Execute command in Pod
- k8s_log - Fetch logs from Kubernetes resources

v0.9.0
======

Major Changes
-------------

- k8s - Inventory source migrated from Ansible 2.9 to Kubernetes collection.
- k8s - Lookup plugin migrated from Ansible 2.9 to Kubernetes collection.
- k8s - Module migrated from Ansible 2.9 to Kubernetes collection.
- k8s_auth - Module migrated from Ansible 2.9 to Kubernetes collection.
- k8s_config_resource_name - Filter plugin migrated from Ansible 2.9 to Kubernetes collection.
- k8s_info - Module migrated from Ansible 2.9 to Kubernetes collection.
- k8s_scale - Module migrated from Ansible 2.9 to Kubernetes collection.
- k8s_service - Module migrated from Ansible 2.9 to Kubernetes collection.
- kubectl - Connection plugin migrated from Ansible 2.9 to Kubernetes collection.
- openshift - Inventory source migrated from Ansible 2.9 to Kubernetes collection.
